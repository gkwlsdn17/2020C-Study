﻿namespace Login
{
    partial class SignUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SignUp));
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.rbtn_comCustomer = new System.Windows.Forms.RadioButton();
            this.rbtn_customer = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.text_name = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_SignUp = new System.Windows.Forms.Button();
            this.btn_idCheck = new System.Windows.Forms.Button();
            this.text_id = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.text_pw = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.text_addr = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.text_email = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.text_comTel = new System.Windows.Forms.TextBox();
            this.text_comNum = new System.Windows.Forms.TextBox();
            this.text_comAddr = new System.Windows.Forms.TextBox();
            this.text_comName = new System.Windows.Forms.TextBox();
            this.text_phone = new System.Windows.Forms.TextBox();
            this.btn_exit = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("HY강M", 15F);
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label12.Location = new System.Drawing.Point(684, 530);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(136, 20);
            this.label12.TabIndex = 69;
            this.label12.Text = "기업 전화번호";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("HY강M", 15F);
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label11.Location = new System.Drawing.Point(684, 450);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(109, 20);
            this.label11.TabIndex = 66;
            this.label11.Text = "사업자번호";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("HY강M", 15F);
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label10.Location = new System.Drawing.Point(683, 370);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(89, 20);
            this.label10.TabIndex = 63;
            this.label10.Text = "기업주소";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("HY강M", 15F);
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label9.Location = new System.Drawing.Point(684, 287);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(69, 20);
            this.label9.TabIndex = 60;
            this.label9.Text = "기업명";
            // 
            // rbtn_comCustomer
            // 
            this.rbtn_comCustomer.AutoSize = true;
            this.rbtn_comCustomer.Font = new System.Drawing.Font("HY강M", 15F);
            this.rbtn_comCustomer.Location = new System.Drawing.Point(364, 126);
            this.rbtn_comCustomer.Name = "rbtn_comCustomer";
            this.rbtn_comCustomer.Size = new System.Drawing.Size(114, 24);
            this.rbtn_comCustomer.TabIndex = 1;
            this.rbtn_comCustomer.TabStop = true;
            this.rbtn_comCustomer.Text = "기업 회원";
            this.rbtn_comCustomer.UseVisualStyleBackColor = true;
            // 
            // rbtn_customer
            // 
            this.rbtn_customer.AutoSize = true;
            this.rbtn_customer.Font = new System.Drawing.Font("HY강M", 15F);
            this.rbtn_customer.Location = new System.Drawing.Point(161, 126);
            this.rbtn_customer.Name = "rbtn_customer";
            this.rbtn_customer.Size = new System.Drawing.Size(114, 24);
            this.rbtn_customer.TabIndex = 58;
            this.rbtn_customer.TabStop = true;
            this.rbtn_customer.Text = "개인 회원";
            this.rbtn_customer.UseVisualStyleBackColor = true;
            this.rbtn_customer.CheckedChanged += new System.EventHandler(this.rbtn_customer_CheckedChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("HY강M", 15F);
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label8.Location = new System.Drawing.Point(684, 210);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 20);
            this.label8.TabIndex = 55;
            this.label8.Text = "전화번호";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("HY강M", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(118, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 27);
            this.label3.TabIndex = 0;
            this.label3.Text = "회원가입";
            // 
            // text_name
            // 
            this.text_name.Font = new System.Drawing.Font("HY강M", 15F);
            this.text_name.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.text_name.Location = new System.Drawing.Point(105, 236);
            this.text_name.Name = "text_name";
            this.text_name.Size = new System.Drawing.Size(391, 30);
            this.text_name.TabIndex = 2;
            this.text_name.Text = " User Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("HY강M", 15F);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label1.Location = new System.Drawing.Point(101, 210);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 20);
            this.label1.TabIndex = 37;
            this.label1.Text = "이름";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel1.Controls.Add(this.btn_exit);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1200, 85);
            this.panel1.TabIndex = 36;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 64);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // btn_SignUp
            // 
            this.btn_SignUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.btn_SignUp.FlatAppearance.BorderSize = 0;
            this.btn_SignUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_SignUp.Font = new System.Drawing.Font("HY강M", 15F);
            this.btn_SignUp.ForeColor = System.Drawing.Color.White;
            this.btn_SignUp.Location = new System.Drawing.Point(525, 674);
            this.btn_SignUp.Name = "btn_SignUp";
            this.btn_SignUp.Size = new System.Drawing.Size(151, 58);
            this.btn_SignUp.TabIndex = 13;
            this.btn_SignUp.Text = "회원가입";
            this.btn_SignUp.UseVisualStyleBackColor = false;
            this.btn_SignUp.Click += new System.EventHandler(this.btn_SignUp_Click);
            // 
            // btn_idCheck
            // 
            this.btn_idCheck.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.btn_idCheck.FlatAppearance.BorderSize = 0;
            this.btn_idCheck.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_idCheck.Font = new System.Drawing.Font("HY강M", 12F);
            this.btn_idCheck.ForeColor = System.Drawing.Color.White;
            this.btn_idCheck.Location = new System.Drawing.Point(407, 316);
            this.btn_idCheck.Name = "btn_idCheck";
            this.btn_idCheck.Size = new System.Drawing.Size(89, 30);
            this.btn_idCheck.TabIndex = 4;
            this.btn_idCheck.Text = "중복확인";
            this.btn_idCheck.UseVisualStyleBackColor = false;
            this.btn_idCheck.Click += new System.EventHandler(this.btn_idCheck_Click);
            // 
            // text_id
            // 
            this.text_id.Font = new System.Drawing.Font("HY강M", 15F);
            this.text_id.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.text_id.Location = new System.Drawing.Point(105, 316);
            this.text_id.Name = "text_id";
            this.text_id.Size = new System.Drawing.Size(293, 30);
            this.text_id.TabIndex = 3;
            this.text_id.Text = " User ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("HY강M", 15F);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label2.Location = new System.Drawing.Point(101, 290);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 20);
            this.label2.TabIndex = 74;
            this.label2.Text = "아이디";
            // 
            // text_pw
            // 
            this.text_pw.Font = new System.Drawing.Font("HY강M", 15F);
            this.text_pw.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.text_pw.Location = new System.Drawing.Point(105, 396);
            this.text_pw.Name = "text_pw";
            this.text_pw.PasswordChar = '●';
            this.text_pw.Size = new System.Drawing.Size(391, 30);
            this.text_pw.TabIndex = 5;
            this.text_pw.Text = " User Password";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("HY강M", 15F);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label4.Location = new System.Drawing.Point(101, 370);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 20);
            this.label4.TabIndex = 76;
            this.label4.Text = "비밀번호";
            // 
            // text_addr
            // 
            this.text_addr.Font = new System.Drawing.Font("HY강M", 15F);
            this.text_addr.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.text_addr.Location = new System.Drawing.Point(105, 476);
            this.text_addr.Name = "text_addr";
            this.text_addr.Size = new System.Drawing.Size(391, 30);
            this.text_addr.TabIndex = 6;
            this.text_addr.Text = " 대구광역시 동구 아양로 42길";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("HY강M", 15F);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label5.Location = new System.Drawing.Point(101, 450);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 20);
            this.label5.TabIndex = 78;
            this.label5.Text = "주소";
            // 
            // text_email
            // 
            this.text_email.Font = new System.Drawing.Font("HY강M", 15F);
            this.text_email.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.text_email.Location = new System.Drawing.Point(105, 556);
            this.text_email.Name = "text_email";
            this.text_email.Size = new System.Drawing.Size(391, 30);
            this.text_email.TabIndex = 7;
            this.text_email.Text = " someone@email.com";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("HY강M", 15F);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label6.Location = new System.Drawing.Point(101, 530);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 20);
            this.label6.TabIndex = 80;
            this.label6.Text = "이메일";
            // 
            // text_comTel
            // 
            this.text_comTel.Font = new System.Drawing.Font("HY강M", 15F);
            this.text_comTel.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.text_comTel.Location = new System.Drawing.Point(688, 556);
            this.text_comTel.Name = "text_comTel";
            this.text_comTel.Size = new System.Drawing.Size(391, 30);
            this.text_comTel.TabIndex = 12;
            this.text_comTel.Text = " 000-000-0000";
            // 
            // text_comNum
            // 
            this.text_comNum.Font = new System.Drawing.Font("HY강M", 15F);
            this.text_comNum.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.text_comNum.Location = new System.Drawing.Point(688, 476);
            this.text_comNum.Name = "text_comNum";
            this.text_comNum.Size = new System.Drawing.Size(391, 30);
            this.text_comNum.TabIndex = 11;
            this.text_comNum.Text = " 0123456789";
            // 
            // text_comAddr
            // 
            this.text_comAddr.Font = new System.Drawing.Font("HY강M", 15F);
            this.text_comAddr.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.text_comAddr.Location = new System.Drawing.Point(688, 396);
            this.text_comAddr.Name = "text_comAddr";
            this.text_comAddr.Size = new System.Drawing.Size(391, 30);
            this.text_comAddr.TabIndex = 10;
            this.text_comAddr.Text = " 대구광역시 동구 신천3동";
            // 
            // text_comName
            // 
            this.text_comName.Font = new System.Drawing.Font("HY강M", 15F);
            this.text_comName.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.text_comName.Location = new System.Drawing.Point(688, 316);
            this.text_comName.Name = "text_comName";
            this.text_comName.Size = new System.Drawing.Size(391, 30);
            this.text_comName.TabIndex = 9;
            this.text_comName.Text = " 경북산업직업전문학원";
            // 
            // text_phone
            // 
            this.text_phone.Font = new System.Drawing.Font("HY강M", 15F);
            this.text_phone.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.text_phone.Location = new System.Drawing.Point(688, 236);
            this.text_phone.Name = "text_phone";
            this.text_phone.Size = new System.Drawing.Size(391, 30);
            this.text_phone.TabIndex = 8;
            this.text_phone.Text = " 010-0000-0000";
            // 
            // btn_exit
            // 
            this.btn_exit.Dock = System.Windows.Forms.DockStyle.Right;
            this.btn_exit.FlatAppearance.BorderSize = 0;
            this.btn_exit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.btn_exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_exit.Font = new System.Drawing.Font("굴림", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_exit.ForeColor = System.Drawing.Color.White;
            this.btn_exit.Location = new System.Drawing.Point(1137, 0);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(63, 85);
            this.btn_exit.TabIndex = 4;
            this.btn_exit.Text = "x";
            this.btn_exit.UseVisualStyleBackColor = true;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // SignUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1200, 800);
            this.Controls.Add(this.text_comTel);
            this.Controls.Add(this.text_comNum);
            this.Controls.Add(this.text_comAddr);
            this.Controls.Add(this.text_comName);
            this.Controls.Add(this.text_phone);
            this.Controls.Add(this.text_email);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.text_addr);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.text_pw);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.text_id);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_idCheck);
            this.Controls.Add(this.btn_SignUp);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.rbtn_comCustomer);
            this.Controls.Add(this.rbtn_customer);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.text_name);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SignUp";
            this.Text = "SignUp";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton rbtn_comCustomer;
        private System.Windows.Forms.RadioButton rbtn_customer;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox text_name;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_SignUp;
        private System.Windows.Forms.Button btn_idCheck;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox text_id;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox text_pw;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox text_addr;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox text_email;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox text_comTel;
        private System.Windows.Forms.TextBox text_comNum;
        private System.Windows.Forms.TextBox text_comAddr;
        private System.Windows.Forms.TextBox text_comName;
        private System.Windows.Forms.TextBox text_phone;
        private System.Windows.Forms.Button btn_exit;
    }
}