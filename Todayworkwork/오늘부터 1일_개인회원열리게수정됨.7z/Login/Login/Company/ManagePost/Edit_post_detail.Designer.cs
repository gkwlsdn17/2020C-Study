﻿namespace Login.Company.ManagePost
{
    partial class Edit_post_detail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtb_w_num = new System.Windows.Forms.TextBox();
            this.txtb_w_ID = new System.Windows.Forms.TextBox();
            this.txtb_w_pay = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtb_w_field = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtb_w_place = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.datetimeP_From = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.datetimeP_To = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.datetime_finish = new System.Windows.Forms.DateTimePicker();
            this.txtb_w_subject = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtb_w_content = new System.Windows.Forms.TextBox();
            this.btn_confirm_edit = new System.Windows.Forms.Button();
            this.btn_edit_cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(67, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "글번호 ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(275, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(20, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "ID ";
            // 
            // txtb_w_num
            // 
            this.txtb_w_num.Enabled = false;
            this.txtb_w_num.Location = new System.Drawing.Point(118, 27);
            this.txtb_w_num.Name = "txtb_w_num";
            this.txtb_w_num.Size = new System.Drawing.Size(100, 21);
            this.txtb_w_num.TabIndex = 3;
            // 
            // txtb_w_ID
            // 
            this.txtb_w_ID.Enabled = false;
            this.txtb_w_ID.Location = new System.Drawing.Point(326, 27);
            this.txtb_w_ID.Name = "txtb_w_ID";
            this.txtb_w_ID.Size = new System.Drawing.Size(100, 21);
            this.txtb_w_ID.TabIndex = 4;
            // 
            // txtb_w_pay
            // 
            this.txtb_w_pay.Location = new System.Drawing.Point(118, 70);
            this.txtb_w_pay.Name = "txtb_w_pay";
            this.txtb_w_pay.Size = new System.Drawing.Size(100, 21);
            this.txtb_w_pay.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(67, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 5;
            this.label3.Text = "급여";
            // 
            // txtb_w_field
            // 
            this.txtb_w_field.Location = new System.Drawing.Point(326, 70);
            this.txtb_w_field.Name = "txtb_w_field";
            this.txtb_w_field.Size = new System.Drawing.Size(100, 21);
            this.txtb_w_field.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(275, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 7;
            this.label4.Text = "직종";
            // 
            // txtb_w_place
            // 
            this.txtb_w_place.Location = new System.Drawing.Point(118, 112);
            this.txtb_w_place.Name = "txtb_w_place";
            this.txtb_w_place.Size = new System.Drawing.Size(100, 21);
            this.txtb_w_place.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(67, 115);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 9;
            this.label5.Text = "근무지";
            // 
            // datetimeP_From
            // 
            this.datetimeP_From.Location = new System.Drawing.Point(583, 24);
            this.datetimeP_From.Name = "datetimeP_From";
            this.datetimeP_From.Size = new System.Drawing.Size(200, 21);
            this.datetimeP_From.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(510, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 14;
            this.label7.Text = "근무기간";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(581, 57);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(14, 12);
            this.label8.TabIndex = 16;
            this.label8.Text = "~";
            // 
            // datetimeP_To
            // 
            this.datetimeP_To.Location = new System.Drawing.Point(601, 51);
            this.datetimeP_To.Name = "datetimeP_To";
            this.datetimeP_To.Size = new System.Drawing.Size(200, 21);
            this.datetimeP_To.TabIndex = 15;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(510, 117);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 12);
            this.label9.TabIndex = 18;
            this.label9.Text = "접수 마감";
            // 
            // datetime_finish
            // 
            this.datetime_finish.Location = new System.Drawing.Point(583, 112);
            this.datetime_finish.Name = "datetime_finish";
            this.datetime_finish.Size = new System.Drawing.Size(200, 21);
            this.datetime_finish.TabIndex = 17;
            // 
            // txtb_w_subject
            // 
            this.txtb_w_subject.Location = new System.Drawing.Point(118, 174);
            this.txtb_w_subject.Name = "txtb_w_subject";
            this.txtb_w_subject.Size = new System.Drawing.Size(308, 21);
            this.txtb_w_subject.TabIndex = 19;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(67, 177);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 12);
            this.label10.TabIndex = 20;
            this.label10.Text = "제목";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(69, 243);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 12);
            this.label11.TabIndex = 21;
            this.label11.Text = "글내용";
            // 
            // txtb_w_content
            // 
            this.txtb_w_content.Location = new System.Drawing.Point(118, 240);
            this.txtb_w_content.Multiline = true;
            this.txtb_w_content.Name = "txtb_w_content";
            this.txtb_w_content.Size = new System.Drawing.Size(683, 285);
            this.txtb_w_content.TabIndex = 22;
            // 
            // btn_confirm_edit
            // 
            this.btn_confirm_edit.Location = new System.Drawing.Point(277, 541);
            this.btn_confirm_edit.Name = "btn_confirm_edit";
            this.btn_confirm_edit.Size = new System.Drawing.Size(101, 43);
            this.btn_confirm_edit.TabIndex = 23;
            this.btn_confirm_edit.Text = "수정";
            this.btn_confirm_edit.UseVisualStyleBackColor = true;
            this.btn_confirm_edit.Click += new System.EventHandler(this.btn_confirm_edit_Click);
            // 
            // btn_edit_cancel
            // 
            this.btn_edit_cancel.Location = new System.Drawing.Point(434, 541);
            this.btn_edit_cancel.Name = "btn_edit_cancel";
            this.btn_edit_cancel.Size = new System.Drawing.Size(101, 43);
            this.btn_edit_cancel.TabIndex = 24;
            this.btn_edit_cancel.Text = "닫기";
            this.btn_edit_cancel.UseVisualStyleBackColor = true;
            this.btn_edit_cancel.Click += new System.EventHandler(this.btn_edit_cancel_click);
            // 
            // Edit_post_detail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(899, 597);
            this.Controls.Add(this.btn_edit_cancel);
            this.Controls.Add(this.btn_confirm_edit);
            this.Controls.Add(this.txtb_w_content);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtb_w_subject);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.datetime_finish);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.datetimeP_To);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.datetimeP_From);
            this.Controls.Add(this.txtb_w_place);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtb_w_field);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtb_w_pay);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtb_w_ID);
            this.Controls.Add(this.txtb_w_num);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Edit_post_detail";
            this.Text = "Show_post_detail";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Edit_post_detail_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtb_w_num;
        private System.Windows.Forms.TextBox txtb_w_ID;
        private System.Windows.Forms.TextBox txtb_w_pay;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtb_w_field;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtb_w_place;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker datetimeP_From;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker datetimeP_To;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker datetime_finish;
        private System.Windows.Forms.TextBox txtb_w_subject;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtb_w_content;
        private System.Windows.Forms.Button btn_confirm_edit;
        private System.Windows.Forms.Button btn_edit_cancel;
    }
}